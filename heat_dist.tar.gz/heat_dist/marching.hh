#ifndef MARCHING_H_
#define MARCHING_H_

void setupmarch();
void march(double *dists);

#endif /* MARCHING_H_ */
