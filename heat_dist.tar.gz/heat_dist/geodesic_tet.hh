#ifndef GEODESIC_TET_H
#define GEODESIC_TET_H
#include <vector>

void setverts(const std::vector<int>&);
void init();
void step0();
void step1(double *);

#endif /* GEODESIC_TET_H */
